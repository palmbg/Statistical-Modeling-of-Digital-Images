source("rreg.fit.R") # read the main function

## auxiliary functions

rr<-function(mu) # metodo da inversao
{
  n<-length(mu)

  u<- runif(n)
  y<- 2*mu*sqrt(-log(1-u)/pi) # metodo da inversao

  y
}

qr<-function(alpha,mu=1) # quantile function
{
  q<- 2*mu*sqrt((-log(1-alpha))/pi)
  q
}

pr<-function(x,mu=1) # cumulative function
{
  p<- 1- exp((-pi*x^2)/(4*mu^2))
  p
}

dr<-function(x,mu=1) # density function
{
  d<- pi*x/(2*mu^2)*exp(-(pi*x^2)/(4*mu^2))
  d
}


## simulation

n<-50 # tamanho amostral

# parametros
beta0<-2
beta1<--1
beta2<-1

# covariaveis
x1<-runif(n)
x2<-rnorm(n)

eta<- beta0+beta1*x1+beta2*x2 # preditor linear
mu<- exp(eta) # media

y<-rr(mu) # variavel dependente

x<-cbind(x1,x2,runif(n)) # mean covariates 

fit <- rr.fit(x,y) # fit the model


set.seed(210)
n<-20 # tamanho amostral

# parametros
beta0<- 0.5
beta1<--0.15


# covariaveis
x1<-seq(1,n,by=0.25)

eta<- beta0+beta1*x1 # preditor linear
mu<- exp(eta) # media

y<-rr(mu) # variavel dependente

plot(x1,y,type="l")
lines(x1,mu)

fit <- rr.fit(x1,y) # fit the model



### Real data
data<- read.table("aminzadeh1993.txt",h=T)
head(data)
attach(data)

fit <- rr.fit(X,Y) # fit the model

plot(Y)
lines(fit$mu.hat,col="blue")




############## SAR image San Francisco
library(jpeg)
img_sf <- readJPEG("goldengate360-2.04001.jpg")
image(img_sf)

x<-img_sf[800:1100,620:950]

image(x)
segments(0.65,0.45,0.7,0.5) # urban
segments(0.5,0.5,0.55,0.55) # forest


urban<- x[round(0.45*(dim(x)[1])):round(0.50*(dim(x)[1])),round(0.65*(dim(x)[2])):round(0.70*(dim(x)[2]))] 
urban2<- x[round(0.5*(dim(x)[1])):round(0.55*(dim(x)[1])),round(0.65*(dim(x)[2])):round(0.70*(dim(x)[2]))] #tbm urban
forest<- x[round(0.50*(dim(x)[1])):round(0.55*(dim(x)[1])),round(0.5*(dim(x)[2])):round(0.55*(dim(x)[2]))]
agua <- x[round(0.3*(dim(x)[1])):round(0.35*(dim(x)[1])),round(0.3*(dim(x)[2])):round(0.35*(dim(x)[2]))] 

image(urban)
image(urban2)
image(forest)
image(agua)

## apenas urban and forest
y<- c(as.vector(urban),as.vector(forest))
b<- c(rep(0,length(as.vector(urban))),rep(1,length(as.vector(forest))))

source("rreg.fit.R") # read the main function
fit <- rr.fit(b,y) # fit the model

## urban 1 e 2 e forest

y<- c(as.vector(urban),as.vector(forest),as.vector(urban2))
b1<- c(rep(0,length(as.vector(urban))),rep(1,length(as.vector(forest))),rep(0,length(as.vector(urban2))))
b2<- c(rep(0,length(as.vector(urban))),rep(0,length(as.vector(forest))),rep(1,length(as.vector(urban2))))

b<-cbind(b1,b2)

fit <- rr.fit(b,y) # fit the model


## urban 1 e 2, forest e agua

y<- c(as.vector(urban),as.vector(forest),as.vector(urban2),as.vector(agua))
b1<- c(rep(0,length(as.vector(urban))),rep(1,length(as.vector(forest))),rep(0,length(as.vector(urban2))),rep(0,length(as.vector(agua))))
b2<- c(rep(0,length(as.vector(urban))),rep(0,length(as.vector(forest))),rep(1,length(as.vector(urban2))),rep(0,length(as.vector(agua))))
b3<- c(rep(0,length(as.vector(urban))),rep(0,length(as.vector(forest))),rep(0,length(as.vector(urban2))),rep(1,length(as.vector(agua))))

b<-cbind(b1,b2,b3)

fit <- rr.fit(b,y) # fit the model

plot(fit$mu.hat)
mu1<-fit$mu.hat[200]
mu2<-fit$mu.hat[400]
mu3<-fit$mu.hat[700]
mu4<-fit$mu.hat[1000]

s<- seq(0.01,0.99,by=0.01)
plot(s,dr(s,mu4),type="l")
lines(s,dr(s,mu2),col=2)
lines(s,dr(s,mu3),col=3)
lines(s,dr(s,mu1),col=4)

par(mfrow=c(2,2))
plot(s,dr(s,mu1),type="l")
plot(s,dr(s,mu2),type="l")
plot(s,dr(s,mu3),type="l")
plot(s,dr(s,mu4),type="l")

hist(urban)
hist(forest)
hist(urban2)
hist(agua)

s<- seq(0.01,0.99,by=0.01)

par(mfrow=c(2,2))
serie<-as.vector(urban)
h<-hist(serie,main="urban")
#s<-seq(min(serie),max(serie),length=40) 
yfit<-dr(s,mu1)
yfit2 <- yfit*diff(h$mids[1:2])*length(serie)
lines(s, yfit2, col="blue", lwd=2)

serie<-as.vector(urban2)
h<-hist(serie,main="urban")
#s<-seq(min(serie),max(serie),length=40) 
yfit<-dr(s,mu3)
yfit2 <- yfit*diff(h$mids[1:2])*length(serie)
lines(s, yfit2, col="blue", lwd=2)

serie<-as.vector(forest)
h<-hist(serie,main="forest")
#s<-seq(min(serie),max(serie),length=40) 
yfit<-dr(s,mu2)
yfit2 <- yfit*diff(h$mids[1:2])*length(serie)
lines(s, yfit2, col="blue", lwd=2)

serie<-as.vector(agua)
h<-hist(serie,main="water")
#s<-seq(min(serie),max(serie),length=40) 
yfit<-dr(s,mu4)
yfit2 <- yfit*diff(h$mids[1:2])*length(serie)
lines(s, yfit2, col="blue", lwd=2)


